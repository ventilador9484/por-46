
### Características de la Etapa 2:
##### Al presionar el botón de Espacio, el jugador tiene una segunda oportunidad de jugar.
##### Los bloques desaparecen al entrar en contacto con mi resortera





